package p

func f() bool {
	return true
}
