package main

import "testing"

func TestF(t *testing.T) {

}

func BenchmarkF(t *testing.B) {

}

func ExampleF() {

}
