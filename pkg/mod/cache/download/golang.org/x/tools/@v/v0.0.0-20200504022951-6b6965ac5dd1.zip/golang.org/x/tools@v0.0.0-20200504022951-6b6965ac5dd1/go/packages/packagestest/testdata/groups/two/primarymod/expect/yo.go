package expect

var X int //@check("X", "X")
